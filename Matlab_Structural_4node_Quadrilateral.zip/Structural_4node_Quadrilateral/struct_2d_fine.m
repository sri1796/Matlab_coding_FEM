E = 30e6; nu = 0.25; strs_flg = 1; 

[C] = constitutive(E, nu, strs_flg);

connect = [1,2,5,4;
           2,3,6,5;
           5,6,9,8;
           4,5,8,7];


% Gausspoints for 3x3 line integration
% --------------------------------
xi = [-0.774597, 0.774597, 0];
xiw = [5/9, 5/9, 8/9];

eta = [-0.774597, 0.774597, 0];
etaw = [5/9, 5/9, 8/9];

% Element 1
coord = [0.0, 0.0;
         1.5, 0.0;
         1.5, 1;
         0, 1];
     
 % Sum over gauss points:
 ke1 = zeros(8,8);
 for i = 1:3
     for j = 1:3
         keg = elestiff(xi(i), eta(j), coord, C);
         ke1 = ke1 + keg*xiw(i)*etaw(j);
     end
 end
 
 
 
 % Element 2
coord = [1.5, 0.0;
         3, 0.0;
         3, 1;
         1.5, 1];
     
 % Sum over gauss points:
 ke2 = zeros(8,8);
 for i = 1:3
     for j = 1:3
         keg = elestiff(xi(i), eta(j), coord, C);
         ke2 = ke2 + keg*xiw(i)*etaw(j);
     end
 end
 
 edgeno = 2;
 tvec = [150;0];
 fe2 = zeros(8,1);
 for i = 1:3
    feg = gamat(xi(i), coord, tvec, edgeno);
    fe2 = fe2 + feg*xiw(i);
 end
 
 % Element 3
coord = [1.5, 1.0;
         3, 1.0;
         3, 2;
         1.5, 2];
     
 % Sum over gauss points:
 ke3 = zeros(8,8);
 for i = 1:3
     for j = 1:3
         keg = elestiff(xi(i), eta(j), coord, C);
         ke3 = ke3 + keg*xiw(i)*etaw(j);
     end
 end
 
 edgeno = 2;
 tvec = [100;0];
 fe3 = zeros(8,1);
 for i = 1:3
    feg = gamat(xi(i), coord, tvec, edgeno);
    fe3 = fe3 + feg*xiw(i);
 end
     
  % Element 4
coord = [0, 1.0;
         1.5, 1.0;
         1.5, 2;
         0, 2];
     
 % Sum over gauss points:
 ke4 = zeros(8,8);
 for i = 1:3
     for j = 1:3
         keg = elestiff(xi(i), eta(j), coord, C);
         ke4 = ke4 + keg*xiw(i)*etaw(j);
     end
 end
 
 
     
 
% Assembly
K = zeros(18,18);
F = zeros(18,1);

vec = connect(1,:);
for i = 1:4
    for j = 1:4
        K(2*vec(i)-1:2*vec(i), 2*vec(j)-1:2*vec(j)) = K(2*vec(i)-1:2*vec(i), 2*vec(j)-1:2*vec(j)) + ke1(2*i-1:2*i,2*j-1:2*j);
    end
end

vec = connect(2,:);
for i = 1:4
    for j = 1:4
        K(2*vec(i)-1:2*vec(i), 2*vec(j)-1:2*vec(j)) = K(2*vec(i)-1:2*vec(i), 2*vec(j)-1:2*vec(j)) + ke2(2*i-1:2*i,2*j-1:2*j);
    end
    F(2*vec(i)-1:2*vec(i)) =  F(2*vec(i)-1:2*vec(i)) + fe2(2*i-1:2*i);
end
        
vec = connect(3,:);
for i = 1:4
    for j = 1:4
        K(2*vec(i)-1:2*vec(i), 2*vec(j)-1:2*vec(j)) = K(2*vec(i)-1:2*vec(i), 2*vec(j)-1:2*vec(j)) + ke3(2*i-1:2*i,2*j-1:2*j);
    end
    F(2*vec(i)-1:2*vec(i)) =  F(2*vec(i)-1:2*vec(i)) + fe3(2*i-1:2*i);
end

vec = connect(4,:);
for i = 1:4
    for j = 1:4
        K(2*vec(i)-1:2*vec(i), 2*vec(j)-1:2*vec(j)) = K(2*vec(i)-1:2*vec(i), 2*vec(j)-1:2*vec(j)) + ke4(2*i-1:2*i,2*j-1:2*j);
    end
    
end

% Imposition of B.C.
Kreduce = K([3:5,7:12,15:18],[3:5,7:12,15:18]);
Freduce = F([3:5,7:12,15:18]);

% Finding Solution
ureduce = inv(Kreduce)*Freduce;
un = [0;0;ureduce(1:3);0;ureduce(4:9);0;0;ureduce(10:13)];

% % % ==============================================
% % %% Printing Intermediate Result to The Output File
% % % ------------------------------------------------
% fid=fopen('Steps','w');
% fprintf(fid,'The Element Load Vector are\n');
% fprintf(fid,'===================================\n\n');
% 
% fprintf(fid,'fe1 \n');
% fprintf(fid,'-----\n\n');
% for i = 1:6
%    fprintf(fid,'%14.4e\t',fe1(i));
% end
% fprintf(fid,'\nfe2 \n');
% fprintf(fid,'-----\n\n');
% for i = 1:6
%    fprintf(fid,'%14.4e\t',fe2(i));
% end
% fprintf(fid,'\nfe3 \n');
% fprintf(fid,'-----\n\n');
% for i = 1:6
%    fprintf(fid,'%14.4e\t',fe3(i));
% end
% 
% fprintf(fid,'\n\nThe Global Stiffness matrix is\n');
% fprintf(fid,'==================================\n\n');
% fprintf(fid,'K\n');
% fprintf(fid,'--\n');
% for i = 1:12
%    fprintf(fid,'%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\n\n',K(i,1:6));
% end
% fprintf(fid,'\n\n\n');
% for i = 1:12
%    fprintf(fid,'%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\n\n',K(i,7:12));
% end
% 
% 
% fprintf(fid,'\n\nThe Global Load Vector is\n');
% fprintf(fid,'==================================\n\n');
% fprintf(fid,'F\n');
% fprintf(fid,'--\n');
% for i = 1:12
%    fprintf(fid,'%12.4e\t',F(i));
% end
% 
% fprintf(fid,'\n\nImposition of Boundary Condition\n');
% fprintf(fid,'==================================\n\n');
% fprintf(fid,'K u = F\n');
% fprintf(fid,'--------\n');
% for i = 1:12
%    fprintf(fid,'%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t\t\t\t%12.4e\n\n',K(i,1:12),F(i));
% end
% 
% fprintf(fid,'\n\nReduced Equations\n');
% fprintf(fid,'=======================\n\n');
% fprintf(fid,'K_reduce u = F_reduce\n');
% fprintf(fid,'--------\n');
% for i = 1:9
%    fprintf(fid,'%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t%12.4e\t\t\t\t%12.4e\n\n',Kreduce(i,1:9),Freduce(i));
% end
% 
% fprintf(fid,'\n\nThe Final Solution\n');
% fprintf(fid,'=========================\n\n');
% fprintf(fid,'Tn\n');
% fprintf(fid,'--\n');
% for i = 1:12
%    fprintf(fid,'%12.4e\n\n',un(i));
% end
% 
